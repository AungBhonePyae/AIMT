let name="Mario";
console.log(typeof(name));

let sub='php';
console.log(typeof(sub));

let age=33;
console.log(typeof age);

let length=2.345;
console.log(typeof length);

// null // undefined //array [] // object {}
// boolean //NaN